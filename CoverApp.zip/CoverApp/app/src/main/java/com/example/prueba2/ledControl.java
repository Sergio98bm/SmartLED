package com.example.prueba2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;


import android.app.Notification;
import android.app.NotificationChannel;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.provider.SyncStateContract;
import android.util.Log;
import android.widget.Toast;
import android.graphics.Color;
import android.app.NotificationManager;

public class ledControl extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        Thread thread = new Thread(){
            public void run(){
                runOnUiThread(new Runnable() {
                    public void run() {


                        final NotificationManager mNotifyMgr =(NotificationManager) getApplicationContext().getSystemService(NOTIFICATION_SERVICE);

                        final Handler handler = new Handler();
                        final Handler handler2 = new Handler();

                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {

                                String textoBinarioAux = "00000000111001001000111010011100001010110011100100101"; //Here comes the text to transmit
                                String textoBinario = "";

                                //Text in binary transformed into Manchester codification
                                for(int i=0;i<textoBinarioAux.length();i++){
                                    if(textoBinarioAux.charAt(i) == '0'){
                                        textoBinario = textoBinario + "10";
                                    }else if(textoBinarioAux.charAt(i) == '1'){
                                        textoBinario = textoBinario + "01";
                                    }else{
                                        break; 
                                    }
                                }

                                textoBinario = "10101010" + textoBinario + "2";
                                
                                funcionLed(textoBinario); //Recursive function

                            }
                        }, 3000); 
                    }
                });
            }
        };
        thread.setPriority(Thread.MAX_PRIORITY);
        try {
            thread.start();
            thread.join();
        } catch (InterruptedException e) {

            e.printStackTrace();
        }

        Intent homeIntent = new Intent(Intent.ACTION_MAIN);
        homeIntent.addCategory(Intent.CATEGORY_HOME);
        homeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(homeIntent);
        //finish();

    }

    public void funcionLed(String stringToTransmit){

        final NotificationManager mNotifyMgr =(NotificationManager) getApplicationContext().getSystemService(NOTIFICATION_SERVICE);
        final NotificationCompat.Builder uno =new NotificationCompat.Builder(getApplicationContext(),"1")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setDefaults(Notification.FLAG_SHOW_LIGHTS)
                .setVibrate(new long[]{0L})
                .setLights(Color.rgb(255,0,0), 2100, 450)
                .setAutoCancel(false);

        final Handler handler = new Handler();
        int oneTime=0,zeroTime=0,iteracion =0;
        char digit = stringToTransmit.charAt(0);//Obtenemos el primer digit de la stringToTransmit


        if(digit=='0'){

            while(digit=='0') {
                zeroTime += 300;
                stringToTransmit = stringToTransmit.substring(1);
                digit = stringToTransmit.charAt(0);

            }

            final String auxiliar = stringToTransmit;
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {

                    mNotifyMgr.cancel(1);

                    funcionLed(auxiliar);

                }
            }, zeroTime);

        }else if(digit=='1'){

            while(digit=='1') {
                oneTime += 300;
                stringToTransmit = stringToTransmit.substring(1);
                digit = stringToTransmit.charAt(0);

            }
            mNotifyMgr.notify(1, uno.build());

            final String auxiliar = stringToTransmit;
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {

                    mNotifyMgr.cancel(1);
                    funcionLed(auxiliar);

                }
            }, oneTime);

        }else if(digit=='2'){

            finish(); //Al ser digit 2, debemos parar el programa.
        }

    }

}